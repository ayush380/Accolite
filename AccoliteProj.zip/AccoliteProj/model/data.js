//Class to export Data to desired Component.
function createData() {
	this.data = {
		questions: [
			{
				id: 'Q-101',
				title: "What is India's capital",
				type: 'radiogroup',
				options: ['Delhi', 'Mumbai', 'Kolkatta', 'Pune'],
			},
			{
				id: 'Q-103',
				title:
					"Grand Central Terminal, Park Avenue, New York is the world's",
				type: 'radiogroup',
				options: [
					'largest railway station',
					'highest railway station',
					'longest railway station',
					'None of the above',
				],
			},
			{
				id: 'Q-103',
				title: 'Entomology is the science that studies',
				type: 'dropdown',
				options: [
					'Behavior of human beings',
					'Insects',
					'The origin and history of technical and scientific terms',
					'The formation of rocks',
				],
			},
		],
	};
	this.getData=function(){
		return this.data;
	}
}
