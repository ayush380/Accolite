//Class for DropDown Question
function createDropdownQuestion(question){
  Question.call(this,question);
  this.noOfOptions=question.options.length;
  this.options=question.options;
}
createDropdownQuestion.prototype=Object.create(Question.prototype);