//function to populate options in the divs
function populateOptions(div, question) {
  if (question.type == 'radiogroup') {
    div=radiogroupPopulate(div, question);
  }
  if (question.type == 'dropdown') {
    div=dropdownPopulate(div, question);
  }
  return div;
}

//function to populate radio buttons
function radiogroupPopulate(div, question) {
  let noOfOptions = question.noOfOptions;
  name = 'radio_group_';
  name += div.getAttribute('id');

  for (let j = 0; j < noOfOptions; j++) {
    let inp = document.createElement('input');
    inp.setAttribute('type', 'radio');
    inp.setAttribute('name', name);
    let id = question.id + '_' + j;
    inp.setAttribute('id', id);
    inp.setAttribute('value', question.options[j]);
    var label = document.createElement('label');
    label.appendChild(inp);
    label.innerHTML += '<span> ' + question.options[j] + '</span><br>';
    div.appendChild(label);
  }
  return div;
}
//function to populate dropdown list 
function dropdownPopulate(div, question) {
  let noOfOptions = question.noOfOptions;
  let inp = document.createElement('select');
  id = 'drop_down_';
  id += div.getAttribute('id');
  inp.setAttribute('id',id);
  inp.setAttribute('onchange','dropDownSum(id)');
  defaultOption=document.createElement('option');
  defaultOption.setAttribute('value', "");
  defaultOption.innerHTML="SELECT";
  inp.appendChild(defaultOption);
  for (let j = 0; j < noOfOptions; j++) {
    options = document.createElement('option');
    options.setAttribute('value', question.options[j]);
    options.innerHTML = question.options[j];
    inp.appendChild(options);
  }
  div.appendChild(inp);
  div.appendChild(document.createElement('br'));
  return div;
}

